sudo cp -r public/ /var/www
