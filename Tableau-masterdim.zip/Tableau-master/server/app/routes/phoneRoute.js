var pnf   = require('google-libphonenumber').PhoneNumberFormat;
var mysql = require('mysql');

module.exports = function(router, connection) {
    router.route('/phoneCheck')
        .post(function(req, res) {
            // Get an instance of `PhoneNumberUtil`.
            var phoneUtil = require('google-libphonenumber').PhoneNumberUtil.getInstance();

            // Parse number with country code.
            var phoneNumber = phoneUtil.parse(req.body.phone, req.body.country_code);

            // Print number in the international format.
            var result = phoneUtil.format(phoneNumber, pnf.INTERNATIONAL);

            if (!result)
                res.status(400).send("bad result");
            else
                res.json(result);
        })

}
