var mysql = require('mysql');

module.exports = function(router, connection) {
      router.route('/getProfil')
        .get(function(req, res) {
            var query    = "SELECT ??, ??, ??, ??, ??, \
                                   ??, ??, ??, ??, ??, \
                                   ??, ??, ??, ??, ??, \
                                   ??, ??, ??, ??, ??, \
                                   ??, ??, ??, ??, ??  \
                            FROM ?? c \
                            LEFT JOIN ?? cca ON ?? = ?? AND ?? = ?? \
                            LEFT JOIN ?? p   ON ?? = ?? AND ?? = ?? \
                            LEFT JOIN ?? pa  ON ?? = ?? AND ?? = ?? \
                            LEFT JOIN ?? e   ON ?? = ?? AND ?? = ?? \
                            LEFT JOIN ?? d   ON ?? = ?? AND ?? = ?? LIMIT 0, 10"
            var table    = ['c.Customer_Gender', 'c.Customer_BirthDate','c.Customer_surName','c.Customer_NameTitle','c.Customer_MiddleName',
                            'c.Customer_Contact_EmergencyFlag','c.Customer_Contact_Name','c.Customer_GivenName','cca.Name','cca.CompanyName',
                            'cca.AddressLine','cca.CityName','cca.CityName_PostalCode','cca.CountryName', 'p.PhoneNumber',
                            'pa.FirstName', 'pa.LastName','pa.PreferredApproverTravelerID', 'e.Email','d.DocumentId',
                            'd.DocId','d.DocHolderName','d.DocLimitations','d.ExpireDate', 'd.DocIssueLocation',

                            'profils.customer',
                            'profils.credit_card_address', 'c.SITE_ID',  'cca.SITE_ID', 'c.UID',  'cca.UID',
                            'profils.phone',               'p.SITE_ID',  'cca.SITE_ID', 'p.UID',  'cca.UID',
                            'profils.preferred_approver',  'pa.SITE_ID', 'cca.SITE_ID', 'pa.UID', 'cca.UID',
                            'profils.email',               'e.SITE_ID',  'cca.SITE_ID', 'e.UID',  'cca.UID',
                            'profils.document',            'd.SITE_ID',  'cca.SITE_ID', 'd.UID',  'cca.UID'];
            query = mysql.format(query, table);
            // query = mysql.format(query, table);
            connection.query(query, function(err, rows) {
                if (err)
                    res.status(400).send("Bad realm !");
                else
                    res.json(rows);
            });
        })
}
